
------
Команды для настройки газебо в терминале виртуалки + доп коды по open cv
https://github.com/Galina-Basargina/aruco_flights
------
Генерация qr:
https://github.com/mikemka/gazebo_qr_gen
------